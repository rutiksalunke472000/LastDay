package com.service;

import java.util.List;

import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.model.Invoice;
import com.repository.InvoiceRepo;

@Transactional
@Service
public class InvoiceServiceImpl implements InvoiceService {
	@Autowired
	InvoiceRepo invoiceRepo;

	
	public List<Invoice> getInvoice() {
		
		return invoiceRepo.findAll();
	}

	
	public void saveInvoice(Invoice invoice) {
		invoiceRepo.save(invoice);
		
	}

}
