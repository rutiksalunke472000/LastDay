package com.service;

import java.util.List;
import org.codehaus.jettison.json.JSONObject;

import com.model.Invoice;

public interface InvoiceService {
	
	List<Invoice> getInvoice();
	
	public void saveInvoice(Invoice invoice);

}
