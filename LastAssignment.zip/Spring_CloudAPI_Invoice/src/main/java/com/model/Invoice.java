package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Invoice {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int invoiceId;
	private int totalAmount;
	private String paymentStatus;
	private int orderId;
	
	public Invoice(int invoiceId, int totalAmount, String paymentStatus) {
		super();
		this.invoiceId = invoiceId;
		this.totalAmount = totalAmount;
		this.paymentStatus = paymentStatus;
	}

	public int getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(int invoiceId) {
		this.invoiceId = invoiceId;
	}

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	@Override
	public String toString() {
		return "Invoice [invoiceId=" + invoiceId + ", totalAmount=" + totalAmount + ", paymentStatus=" + paymentStatus
				+ "]";
	}
	
	public Invoice() {
		
	}
	
	
	

}
